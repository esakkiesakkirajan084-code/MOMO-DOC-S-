package com.auditkit.shizukupre

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var status: TextView

    private val binderListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { refresh() }
    }
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        runOnUiThread { refresh() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        status = TextView(this).apply { textSize = 14f }

        val shizukuBtn = Button(this).apply {
            text = "Request Shizuku permission"
            setOnClickListener { Sh.request(REQ_SHIZUKU) }
        }
        val openBtn = Button(this).apply {
            text = "Open Shizuku app"
            setOnClickListener {
                val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i != null) startActivity(i)
                else Toast.makeText(this@MainActivity, "Shizuku is not installed", Toast.LENGTH_LONG).show()
            }
        }
        val filesBtn = Button(this).apply {
            text = "Grant All-files access (for bugreport parse)"
            setOnClickListener { openAllFilesSettings() }
        }

        val list = ListView(this)
        list.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_1,
            Features.all.map { "${it.id}. ${it.title}" }
        )
        list.setOnItemClickListener { _, _, pos, _ -> openFeature(Features.all[pos]) }

        root.addView(status)
        root.addView(shizukuBtn)
        root.addView(openBtn)
        root.addView(filesBtn)
        root.addView(list, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        try {
            Shizuku.addBinderReceivedListenerSticky(binderListener)
            Shizuku.addRequestPermissionResultListener(permListener)
        } catch (e: Throwable) {
            // status line still works through onResume
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            Shizuku.removeBinderReceivedListener(binderListener)
            Shizuku.removeRequestPermissionResultListener(permListener)
        } catch (e: Throwable) {
            // ignore
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val run = if (Sh.available()) "RUNNING" else "NOT running (start Shizuku first)"
        val perm = if (Sh.granted()) "GRANTED" else "NOT granted"
        val f = if (Environment.isExternalStorageManager()) "GRANTED" else "NOT granted"
        status.text = "Shizuku service: $run\nShizuku permission: $perm\nAll-files access: $f"
    }

    private fun openAllFilesSettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
    }

    private fun openFeature(f: Feature) {
        if (!Sh.available()) {
            Toast.makeText(this, "Start Shizuku first", Toast.LENGTH_LONG).show()
            return
        }
        if (!Sh.granted()) {
            Toast.makeText(this, "Grant Shizuku permission first", Toast.LENGTH_LONG).show()
            Sh.request(REQ_SHIZUKU)
            return
        }
        if (f.storage && !Environment.isExternalStorageManager()) {
            Toast.makeText(this, "Grant All-files access first", Toast.LENGTH_LONG).show()
            openAllFilesSettings()
            return
        }
        startActivity(Intent(this, ReportActivity::class.java).putExtra("id", f.id))
    }

    companion object {
        private const val REQ_SHIZUKU = 100
    }
}
