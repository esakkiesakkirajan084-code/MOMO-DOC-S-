package com.auditkit.shizukupre

import android.content.Context
import java.io.File
import java.util.zip.ZipFile

class Feature(
    val id: Int,
    val title: String,
    val storage: Boolean,
    val run: (Context) -> String
)

object Features {

    val all: List<Feature> = listOf(
        Feature(45, "Removed-package records (pm list -u)", false) { removedRecords() },
        Feature(46, "Install session history", false) { installSessions() },
        Feature(47, "Battery stats history", false) { batteryStats() },
        Feature(48, "Other apps' Android/data and OBB access", false) { dataObb() },
        Feature(49, "Bugreport capture and parsing", true) { bugreport() }
    )

    fun byId(id: Int): Feature? = all.firstOrNull { it.id == id }

    private val PKG = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

    private fun pkgList(vararg args: String): Set<String> {
        val r = Sh.run(*args)
        return r.out.lineSequence()
            .filter { it.startsWith("package:") }
            .map { it.removePrefix("package:").trim() }
            .filter { it.isNotEmpty() }
            .toSet()
    }

    // ---------------------------------------------------------------- 45

    private fun removedRecords(): String {
        val all = pkgList("pm", "list", "packages", "-u")
        val inst = pkgList("pm", "list", "packages")
        val removed = (all - inst).sorted()
        val sb = StringBuilder("REMOVED-PACKAGE RECORDS (pm list packages -u minus installed)\n\n")
        sb.append("Installed: ").append(inst.size).append("   Known incl. uninstalled: ").append(all.size).append("\n")
        sb.append("Removed records: ").append(removed.size).append("\n\n")
        if (removed.isEmpty()) {
            sb.append("None. This is normal on most phones: Android deletes the record on a full\n")
            sb.append("uninstall. Only apps removed with 'keep data' or for another user stay listed.\n")
            return sb.toString()
        }
        val keys = listOf(
            "versionName=", "firstInstallTime=", "lastUpdateTime=",
            "installerPackageName=", "installInitiatingPackageName=",
            "installOriginatingPackageName="
        )
        for (p in removed.take(80)) {
            sb.append(p)
            if (PKG.matches(p)) {
                val lines = Sh.run("dumpsys", "package", p).out.lines()
                for (k in keys) {
                    val l = lines.firstOrNull { it.contains(k) }
                    if (l != null) sb.append("\n  ").append(l.trim())
                }
            }
            sb.append("\n\n")
        }
        if (removed.size > 80) sb.append("... ").append(removed.size - 80).append(" more not shown\n")
        return sb.toString()
    }

    // ---------------------------------------------------------------- 46

    private fun installSessions(): String {
        val r = Sh.run("dumpsys", "package")
        if (r.out.isEmpty()) return "dumpsys failed: ${r.err}"
        val lines = r.out.lines()
        val heads = listOf("Active install sessions:", "Historical install sessions:")
        val sb = StringBuilder("INSTALL SESSION HISTORY (from dumpsys package)\n\n")
        var found = false
        var emitted = 0
        for ((i, l) in lines.withIndex()) {
            if (heads.any { l.trim().startsWith(it) }) {
                found = true
                sb.append("== ").append(l.trim()).append(" ==\n")
                var j = i + 1
                while (j < lines.size && emitted < 700 &&
                    (lines[j].startsWith(" ") || lines[j].isBlank())) {
                    if (lines[j].isNotBlank()) { sb.append(lines[j]).append("\n"); emitted++ }
                    j++
                }
                sb.append("\n")
            }
        }
        if (!found) {
            sb.append("This Android version does not print install sessions in dumpsys package.\n")
            sb.append("Try the bugreport feature (49), which sometimes keeps them.\n")
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- 47

    private fun batteryStats(): String {
        val sb = StringBuilder("BATTERY STATS HISTORY\n\n")
        val summary = Sh.run("dumpsys", "batterystats")
        val sl = summary.out.lines()
        val idx = sl.indexOfFirst { it.contains("Estimated power use") }
        sb.append("== Estimated power use ==\n")
        if (idx >= 0) {
            for (l in sl.drop(idx).take(70)) sb.append(l).append("\n")
        } else {
            sb.append("(section not present on this device)\n")
        }
        sb.append("\n== Battery history (newest 500 lines) ==\n")
        val h = Sh.run("dumpsys", "batterystats", "--history")
        if (h.out.isBlank()) sb.append("(no history: ").append(h.err).append(")\n")
        else for (l in h.out.lines().takeLast(500)) sb.append(l).append("\n")
        return sb.toString()
    }

    // ---------------------------------------------------------------- 48

    private fun dataObb(): String {
        val inst = pkgList("pm", "list", "packages") + pkgList("pm", "list", "packages", "-u")
        val liveOnly = pkgList("pm", "list", "packages")
        val sb = StringBuilder("OTHER APPS' Android/data, OBB and media (read through Shizuku)\n\n")
        for (dir in listOf("/sdcard/Android/data", "/sdcard/Android/obb", "/sdcard/Android/media")) {
            sb.append("== ").append(dir).append(" ==\n")
            val du = Sh.run("sh", "-c", "du -sk $dir/* 2>/dev/null")
            val rows = du.out.lines().mapNotNull { line ->
                val parts = line.split("\t", limit = 2)
                if (parts.size < 2) null else {
                    val kb = parts[0].trim().toLongOrNull()
                    val name = parts[1].trim().substringAfterLast('/')
                    if (kb == null) null else Pair(name, kb)
                }
            }
            if (rows.isEmpty()) {
                sb.append("(empty or not readable)\n\n")
                continue
            }
            val orphans = rows.filter { PKG.matches(it.first) && it.first !in liveOnly }
            sb.append("Folders: ").append(rows.size).append("   Leftovers from removed apps: ").append(orphans.size).append("\n\n")

            if (orphans.isNotEmpty()) {
                sb.append("-- Leftovers (app not installed) --\n")
                val shown = orphans.sortedByDescending { it.second }.take(150)
                val paths = shown.joinToString(" ") { "$dir/${it.first}" }
                val st = Sh.run("sh", "-c", "stat -c '%y|%n' $paths 2>/dev/null")
                val mod = HashMap<String, String>()
                for (l in st.out.lines()) {
                    val a = l.split("|", limit = 2)
                    if (a.size == 2) mod[a[1].trim().substringAfterLast('/')] = a[0].substringBefore('.').trim()
                }
                for ((name, kb) in shown) {
                    val known = if (name in inst) "(record kept)" else ""
                    sb.append(name).append("  ").append(U.size(kb * 1024)).append("  last changed ")
                        .append(mod[name] ?: "?").append(" ").append(known).append("\n")
                }
                sb.append("\n")
            }
            sb.append("-- Largest 15 folders overall --\n")
            for ((name, kb) in rows.sortedByDescending { it.second }.take(15)) {
                sb.append(name).append("  ").append(U.size(kb * 1024)).append("\n")
            }
            sb.append("\n")
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- 49

    private fun bugreport(): String {
        val sb = StringBuilder("BUGREPORT CAPTURE AND PARSE\n\n")
        sb.append("Running bugreportz (this can take 1-5 minutes)...\n")
        val r = Sh.run("bugreportz")
        var path: String? = r.out.lines().firstOrNull { it.startsWith("OK:") }?.removePrefix("OK:")?.trim()
        if (path == null) {
            val ls = Sh.run("sh", "-c", "ls -t /bugreports/*.zip /data/user_de/0/com.android.shell/files/bugreports/*.zip 2>/dev/null | head -1")
            path = ls.out.lines().firstOrNull { it.endsWith(".zip") }?.trim()
        }
        if (path == null) {
            sb.append("Capture failed.\nstdout: ").append(r.out.take(500)).append("\nstderr: ").append(r.err.take(500)).append("\n")
            return sb.toString()
        }
        sb.append("Created: ").append(path).append("\n")

        val dest = "/sdcard/Download/AuditKit_bugreport_${System.currentTimeMillis() / 1000}.zip"
        val cp = Sh.run("cp", path, dest)
        if (cp.code != 0) {
            sb.append("Copy to Download failed: ").append(cp.err).append("\n")
            return sb.toString()
        }
        sb.append("Saved copy: ").append(dest).append("\n\n")

        val f = File(dest)
        if (!f.exists()) {
            sb.append("Copy is not visible to this app yet. Open it from the Downloads folder.\n")
            return sb.toString()
        }
        try {
            ZipFile(f).use { zip ->
                val entries = zip.entries().toList()
                sb.append("Zip entries: ").append(entries.size).append("  size ").append(U.size(f.length())).append("\n")
                val main = entries.firstOrNull { it.name.endsWith(".txt") && it.name.contains("bugreport") }
                    ?: entries.firstOrNull { it.name.endsWith(".txt") }
                if (main == null) {
                    sb.append("No main text report inside.\n")
                    return sb.toString()
                }
                sb.append("Main report: ").append(main.name).append(" (").append(U.size(main.size)).append(")\n\n")
                val re = Regex("(?i)(uninstall|package removed|removing package|PACKAGE_REMOVED|delete package|install session|installer package)")
                var hits = 0
                var lineNo = 0L
                var sections = 0
                zip.getInputStream(main).bufferedReader().useLines { seq ->
                    for (line in seq) {
                        lineNo++
                        if (line.startsWith("------ ")) sections++
                        if (hits < 400 && re.containsMatchIn(line)) {
                            hits++
                            sb.append(lineNo).append(": ").append(line.trim().take(220)).append("\n")
                        }
                        if (lineNo > 4_000_000L) break
                    }
                }
                sb.insert(sb.indexOf("Main report:"), "Sections: $sections   Lines: $lineNo   Keyword hits shown: $hits\n")
            }
        } catch (e: Exception) {
            sb.append("Parse error: ").append(e).append("\n")
        }
        return sb.toString()
    }
}
