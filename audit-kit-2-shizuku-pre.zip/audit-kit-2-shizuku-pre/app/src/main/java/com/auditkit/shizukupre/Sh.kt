package com.auditkit.shizukupre

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class R(val code: Int, val out: String, val err: String)

object Sh {

    fun available(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun granted(): Boolean = try {
        available() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun request(code: Int) {
        try {
            Shizuku.requestPermission(code)
        } catch (e: Throwable) {
            // ignored: status line in the UI shows the real state
        }
    }

    /** Runs a command as the Shizuku user (shell or root). Blocks until finished. */
    fun run(vararg cmd: String): R {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf(*cmd), null, null) as Process
            var err = ""
            val t = Thread {
                err = try {
                    p.errorStream.bufferedReader().readText()
                } catch (e: Exception) {
                    ""
                }
            }
            t.start()
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            t.join(3000)
            R(code, out, err)
        } catch (e: Throwable) {
            R(-1, "", "Shizuku exec failed: $e")
        }
    }
}

object U {
    private val full = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    fun t(ms: Long): String = if (ms <= 0L) "-" else synchronized(full) { full.format(Date(ms)) }
    fun size(b: Long): String = when {
        b >= 1L shl 30 -> "%.2f GB".format(b / (1024.0 * 1024 * 1024))
        b >= 1L shl 20 -> "%.2f MB".format(b / (1024.0 * 1024))
        b >= 1L shl 10 -> "%.1f KB".format(b / 1024.0)
        else -> "$b B"
    }
}
