# Audit Kit 2 — Pre-install forensics WITH Shizuku

App 2 of 3. Uses Shizuku (shell-level access) to read past data that normal apps cannot.
Requires Android 11+ and the Shizuku app running (wireless debugging or root start).

| # | Feature | How |
|---|---------|-----|
| 45 | Removed-package records | `pm list packages -u` minus installed, plus `dumpsys package <pkg>` details |
| 46 | Install session history | `dumpsys package` (Active/Historical install sessions) |
| 47 | Battery stats history | `dumpsys batterystats` + `--history` |
| 48 | Other apps' Android/data, OBB, media | `du`/`stat` as shell user; flags leftovers of removed apps |
| 49 | Bugreport capture + parse | `bugreportz`, copied to Downloads, keyword-scanned |

Every report has Copy and Save .txt.

## Use
1. Install and start Shizuku. 2. Open this app -> **Request Shizuku permission** -> allow.
3. For feature 49 also grant All-files access. 4. Tap a feature.

## Build
Push to GitHub; Actions -> *Build APK* -> download `audit-kit-2-debug-apk`.

## Honest limits
- 45: Android removes the record on a normal uninstall, so this list is often empty.
- 46: some Android versions no longer print install sessions.
- 48: folder "last changed" time is the best available proxy for last use of a removed app.
- 49: takes minutes; the parse is a keyword scan, not a full forensic analysis.
- Items 50-66 (live logging, actions on flagged apps) belong to App 3.
